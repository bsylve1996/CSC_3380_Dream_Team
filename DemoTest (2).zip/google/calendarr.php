<html>
    <head>
        <title>Calendar</title>
        <!-- <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
        <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
         <link rel="stylesheet" type="text/css" href="calendarr.css">
        <!-- <style>
    .navbar {
    overflow: hidden;
    background-color: #a068b1;
    font-family: Arial, Helvetica, sans-serif;
}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: #d6af38;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #a068b1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #d6af38;
}

.dropdown:hover .dropdown-content {
    display: block;
}
</style> -->

    </head>
    <!-- <body>
        <main>	
            <button id ="theme_btn"> Theme</button> </main>
            <script type="text/javascript" src="calendarr.js"></script>
                <div class="navbar">
                <!-- <a href="http://localhost/google/testpage.php"><img src = 'images/logo1.png'></a></a>
                    <a href="#home">Home</a>
                    <div class="dropdown">
                        <button class="dropbtn">Calendar 
                        <i class="fa fa-caret-down"></i>
                        </button>
                        <div class="dropdown-content">
                        <a href="#">Gregorian</a>
                        <a href="#">Lunar</a>

                        </div>
                    </div> 
                        <a href="#note">Notes</a>
                        <a href="#about">About</a>

            <!-- <div class="navbar">
            <a href="http://localhost/google/testpage.php"><img src = 'images/logo1.png'></a></a>
            <a href="testpage.php">Home</a>
            <a href="mooncalendar.php">Calendar</a>
            <a href="#contact">Contact</a>
            <a href="notekeeping.php">Notes</a>
            <a href="about.php">About</a> -->
                <!-- <div class="dropdown">
                    <a href="#" class="dropdown-toggle profile-image" data-toggle="dropdown">
                    <?php include_once 'google.php';
                    echo $profile;
                    echo $name; ?> 
                    <b class="caret"></b></a>
                    <div class="dropdown-content">
                        <a href="#">Account</a>
                        <a href="logout.php">Sign-out</a>
                	</div>
				</div>
        </div>
</div>

<!-- <div style="padding-left:16px">
 <div class="bodycontainer">
	<div id ="sidepane">
	 <h1>Time</h1>
        <p id ="time"></p>
        <script> 
            document.getElementById('time').innerHTML = localStorage.getItem('time');
        </script>
     	</div>
        <div id="calendar-container">
            <div id="calendar-header">
                <span id="calendar-month-year"></span>
            </div>
            <div id="calendar-dates">
            </div>
        </div>
		<div id = "event-container">
        </div>
</div>
	<div id = "bottombar">
        
    </div>
</div>
    </body>
</html> -->

<body>
<main>	
            <button id ="theme_btn"> Theme</button> </main>
            <script type="text/javascript" src="calendarr.js"></script>
<div class="navbar">
<a href="http://localhost/google/testpage.php"><img src = 'images/logo1.png'></a></a>
  <a href="testpage.php">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Calendar 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="calendarr.php" class="active">Gregorian</a>
      <a href="mooncalendar.php">Lunar</a>

    </div>
  </div> 
    <a href="notekeeping.php">Notes</a>
    <a href="about.php">About</a>
    <div class="dropdown">
                    <!-- <a href="#" class="dropdown-toggle profile-image" data-toggle="dropdown"> -->
                    <?php include_once 'google.php';
                    echo $profile;
                    echo $name; ?> 
                    <i class="fa fa-caret-down"></i>
                    <div class="dropdown-content">
                        <a href="#">Account</a>
                        <a href="logout.php">Sign-out</a>
                	</div>
 
</div>
</div>
<div style="padding-left:16px">
 <div class="bodycontainer">
	<div id ="sidepane">
	 <h1>Time</h1>
        <p id ="time"></p>
        <script> 
            document.getElementById('time').innerHTML = localStorage.getItem('time');
        </script>
     	</div>
        <div id="calendar-container">
            <div id="calendar-header">
                <span id="calendar-month-year"></span>
            </div>
            <div id="calendar-dates">
            </div>
        </div>
		<div id = "event-container">
        </div>
</div>
	<div id = "bottombar">
        
    </div>
</div>
    </body>
</html>
</body>
</html>
