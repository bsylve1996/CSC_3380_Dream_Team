
<!--<!DOCTYPE html>
<html lang="en" manifest = "mooncalendar.appcache" type="text/cache-manifest">
   <head>
      <meta charset="utf-8" />
      <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
      <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
      <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <link rel="stylesheet" type="text/css" href="styles/pc.css">
      <link rel="stylesheet" type="text/css" href="calendarr.css">
      <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
      
      <title>
         moon calendar
      </title>
      
   <!-- <link href="css/themes/jquery-ui.min.css" rel="stylesheet" />
   <link href="css/mooncalendar_styles.css" rel="stylesheet" />
   <script src="scripts/jquery/jquery-2.1.1.min.js"></script>
   <script src="jquery-ui.min.js"></script>
   <script src="scripts/jquery/jquery.cookie.js" type="text/javascript"></script>
   <script src="scripts/jquery/jquery-calendars/jquery.calendars.js" type="text/javascript"></script>
   <script src="scripts/jquery/jquery-calendars/jquery.calendars.julian.min.js" type="text/javascript"></script>
   <script src="scripts/jquery/jquery-calendars/jquery.calendars.lang.min.js" type="text/javascript"></script>
   <script src="scripts/jquery/jquery-calendars/jquery.calendars.plus.min.js" type="text/javascript"></script>
   <script src="scripts/DateSelector.js" type="text/javascript"></script>
   <script src="astro/LunarPosition.js" type="text/javascript"></script>
   <script src="astro/SolarPosition.js" type="text/javascript"></script>
   <script src="astro/astro_utils.js" type="text/javascript"></script>
   <script src="scripts/calendar_preferences.js" type="text/javascript"></script>
   <script src="scripts/pmc_utils.js" type="text/javascript"></script>

   <script>
      function addLoadEvent(func)
      {
         var oldonload = window.onload;
         if (typeof window.onload != 'function')
         {
           window.onload = func;
         }
         else
         {
           window.onload = function()
           {
             if (oldonload)
             {
               oldonload();
             }
             func();
           }
         }
      }

      addLoadEvent(function()
      {
         var hasSVG = !!(document.createElementNS &&
                         document.createElementNS('http://www.w3.org/2000/svg', 'svg').createSVGRect);

         var svgWarning = document.getElementById("svgWarning");
         var mooncalendar = document.getElementById("mooncalendar");

         if (hasSVG === false)
         {
           // svgWarning.setAttribute("style", "display:block;");
            mooncalendar.setAttribute("style", "display:none;");
         }
         else
         {
           // svgWarning.setAttribute("style", "display:none;");
            mooncalendar.setAttribute("style", "display:table;");
         }
      });
   </script>

   <script>
      $(document).ready(function()
      {
      
                      
         var mooncalendar = document.getElementById("mooncalendar");
         var svgWarning = document.getElementById("svgWarning");

         
         var hasSVG = !!(document.createElementNS &&
                         document.createElementNS('http://www.w3.org/2000/svg', 'svg').createSVGRect);
         
         if (hasSVG === false)
         {

            mooncalendar.setAttribute("style", "display:none;");
         }

         {
  
            window.preferences.loadPreferences();
            window.preferences.savePreferences();
            
            mooncalendar.setAttribute("style", "display:table;");
                        
            var basewidth = pmc_utils.getBaseWidth(); 
            
            if (basewidth === 6.0)
            {
               $("#DateDisplay").css("font-size", "22.5pt");
               $(".mcds li").css("font-size", "18pt");
            }
            else
            {
               $("#DateDisplay").css("font-size", "30pt");
               $(".mcds li").css("font-size", "24pt");
            }
    
            console.log("Preferences loaded.");
            
            for (key in window.preferences.values)
               console.log("key: " + key + " val: " + window.preferences.values[key]);
            
            
            console.log("Version.revision: " + window.preferences.values["version"] + "." + window.preferences.values["revision"]);
            
            pmc_utils.initWeekdayLabels();
            pmc_utils.initGrid();

            jQuery(document).bind('month_changed_event', pmc_utils.handleMonthChange);

            pmc_utils.setToCurrentDate();
            
            var preferencesDialog = pmc_utils.getPreferencesDialog();
            
            $(function()
            {
               var resetButton = $("#resetButton").text("").append("<img src=images/reset.png />").button();
               resetButton.click(function() {pmc_utils.setToCurrentDate();});


               var settingsButton = $("#settingsButton").text("").append("<img src=images/gear.png />").button();
               settingsButton.click(function() {preferencesDialog.dialog("open"); });

               $("#prefs_tooltips").button().click(pmc_utils.getCheckboxHandler($("#prefs_tooltips"), "tooltips"));
               $("#prefs_northUp").button().click(pmc_utils.getToggleButtonHandler2($("#prefs_northUp"), "northUp"));
               $("#prefs_positionAngle").button().click(pmc_utils.getCheckboxHandler($("#prefs_positionAngle"), "positionAngle"));
               
               $("#prefs_legend").button().click(pmc_utils.getCheckboxHandler($("#prefs_legend"), "legend"));
               $("#prefs_timeFormat").button().click(pmc_utils.getToggleButtonHandler($("#prefs_timeFormat"), "timeFormat"));
               
               $("#prefs_firstDayOfWeek").selectmenu({
                                                        change: function(event, data)
                                                                {
                                                                   window.preferences.values["firstDayOfWeek"] = data.item.value;
                                                                   pmc_utils.triggerRedraw();
                                                                }
                                                     });
               $("#prefs_firstDayOfWeek").selectmenu({width: "auto"});
               $("#prefs_firstDayOfWeek").selectmenu("refresh");
                                                     
               $("#prefs_language").selectmenu({
                                                  change: function(event, data)
                                                          {
                                                             window.preferences.values["language"] = data.item.value;
                                                             pmc_utils.triggerRedraw();
                                                          }
                                                     });
               $("#prefs_language").selectmenu({width: "auto"});
               $("#prefs_language").selectmenu("refresh");
               
               $("#prefs_scaling").selectmenu({
                                                  change: function(event, data)
                                                          {
                                                             window.preferences.values["scaling"] = data.item.value;
                                                             pmc_utils.triggerRedraw();
                                                          }
                                                     });
               $("#prefs_scaling").selectmenu({width: "auto"});
               $("#prefs_scaling").selectmenu("refresh");
               
               $("#prefs_phaseTime").selectmenu({
                                                  change: function(event, data)
                                                          {
                                                             window.preferences.values["phaseTime"] = data.item.value;
                                                             pmc_utils.triggerRedraw();
                                                          }
                                                     });
               $("#prefs_phaseTime").selectmenu({width: "auto"});
               $("#prefs_phaseTime").selectmenu("refresh");
               
               var availableTags = [];
               $("#prefs_gregorianJD1").autocomplete({
                                                        source: availableTags,
                                                        change: pmc_utils.parseDate
                                                     });
            });
         }
      });
   </script>
   
   <!--<![endif]
   <body>
   
           <main> <button id ="theme_btn"> Theme</button> </main>
            <script type="text/javascript" src="calendarr.js"></script>
            <div class="topnav">
            <a href="http://localhost/google/testpage.php"><img src = 'images/logo.png'></a></a>
            <a class="active" href="#home">Home</a>
            <a href="mooncalendar.php">Calendar</a>
            <a href="#contact">Contact</a>
            <a href="index.php">Settings</a>
            <a href="about.php">About</a>
                <div class="dropdown">
                    <a href="#" class="dropdown-toggle profile-image" data-toggle="dropdown">
                    <?php include_once 'google.php';
                    echo $profile;
                    echo $name; ?> 
                    <b class="caret"></b></a>
                    <div class="dropdown-content">
                        <a href="#">Account</a>
                        <a href="logout.php">Sign-out</a>
                	</div>
				</div>
        </div>
   <!--<table id="mooncalendar" class="centered">
   <tr>
   <td class="centered">

   <div id="Outline">
   
      <div id="DateDisplay">
         January 2014 AD
      </div>
      
      <div id="DateSelector">
         <ul class="mcds">
            <li><div id="month">Loading...</div><span id="monthVal">0</span>
               <ul>
                  <li><div id="month0">January</div>  <span class="val">0</span></li>
                  <li><div id="month1">February</div> <span class="val">1</span></li>
                  <li><div id="month2">March</div>    <span class="val">2</span></li>
                  <li><div id="month3">April</div>    <span class="val">3</span></li>
                  <li><div id="month4">May</div>      <span class="val">4</span></li>
                  <li><div id="month5">June</div>     <span class="val">5</span></li>
                  <li><div id="month6">July</div>     <span class="val">6</span></li>
                  <li><div id="month7">August</div>   <span class="val">7</span></li>
                  <li><div id="month8">September</div><span class="val">8</span></li>
                  <li><div id="month9">October</div>  <span class="val">9</span></li>
                  <li><div id="month10">November</div><span class="val">10</span></li>
                  <li><div id="month11">December</div><span class="val">11</span></li>
               </ul>
            </li>

            <li><div id="millenium"></div><span id="milleniumVal">0</span>
               <ul>
                  <li><div id="millenium0">0</div><span class="val">0</span></li>
                  <li><div id="millenium1">1</div><span class="val">1</span></li>
                  <li><div id="millenium2">2</div><span class="val">2</span></li>
                  <li><div id="millenium3">3</div><span class="val">3</span></li>
               </ul>
            </li>
            <li><div id="century"></div><span id="centuryVal">0</span>
               <ul>
                  <li><div id="century0">0</div><span class="val">0</span></li>
                  <li><div id="century1">1</div><span class="val">1</span></li>
                  <li><div id="century2">2</div><span class="val">2</span></li>
                  <li><div id="century3">3</div><span class="val">3</span></li>
                  <li><div id="century4">4</div><span class="val">4</span></li>
                  <li><div id="century5">5</div><span class="val">5</span></li>
                  <li><div id="century6">6</div><span class="val">6</span></li>
                  <li><div id="century7">7</div><span class="val">7</span></li>
                  <li><div id="century8">8</div><span class="val">8</span></li>
                  <li><div id="century9">9</div><span class="val">9</span></li>
               </ul>
            </li>
            <li><div id="decade"></div><span id="decadeVal">0</span>
               <ul>
                  <li><div id="decade0">0</div><span class="val">0</span></li>
                  <li><div id="decade1">1</div><span class="val">1</span></li>
                  <li><div id="decade2">2</div><span class="val">2</span></li>
                  <li><div id="decade3">3</div><span class="val">3</span></li>
                  <li><div id="decade4">4</div><span class="val">4</span></li>
                  <li><div id="decade5">5</div><span class="val">5</span></li>
                  <li><div id="decade6">6</div><span class="val">6</span></li>
                  <li><div id="decade7">7</div><span class="val">7</span></li>
                  <li><div id="decade8">8</div><span class="val">8</span></li>
                  <li><div id="decade9">9</div><span class="val">9</span></li>
               </ul>
            </li>
            <li><div id="year"></div><span id="yearVal">0</span>
               <ul>
                  <li><div id="year0">0</div><span class="val">0</span></li>
                  <li><div id="year1">1</div><span class="val">1</span></li>
                  <li><div id="year2">2</div><span class="val">2</span></li>
                  <li><div id="year3">3</div><span class="val">3</span></li>
                  <li><div id="year4">4</div><span class="val">4</span></li>
                  <li><div id="year5">5</div><span class="val">5</span></li>
                  <li><div id="year6">6</div><span class="val">6</span></li>
                  <li><div id="year7">7</div><span class="val">7</span></li>
                  <li><div id="year8">8</div><span class="val">8</span></li>
                  <li><div id="year9">9</div><span class="val">9</span></li>
               </ul>
            </li>

            <li><div id="epoch"></div><span id="epochVal">0</span>
               <ul>
                  <li><div id="epochAD">AD</div><span class="val">AD</span></li>
                  <li><div id="epochBC">BC</div><span class="val">BC</span></li>
               </ul>
            </li>
         </ul>
      </div>

      <div id="Calendar">
         <svg id="svg_calendar" width="8.0in" height="7.2in" viewBox="0 0 700 730" shape-rendering="geometricPrecision">
            <svg id="weekday_bar" width="700" height="30" ></svg>
            <svg id="calendar_grid" width="700" height="600" y="30" viewBox="0 0 700 600" ></svg>
   
            <svg class="svg_legend" id = "svg_calendar_legend" width = "700" height = "100" y = "330" viewBox="0 0 700 100">
               <circle class = "svg_legend" id = "new_phase1" cx = "12" cy = "15" r = "5"></circle>
               <path class = "svg_legend" id = "new_phase2"  transform = "" d = "M 12,20 A 5,5 0 1,0 12,10 Z"></path>

               <circle class = "svg_legend" id = "q1_phase1" cx = "12" cy = "30" r = "5"></circle>
               <path class = "svg_legend" id = "q1_phase2"   transform = "" d = "M 12,35 A 5,5 0 1,0 12,25 Z"></path>

               <circle class = "svg_legend" id = "full_phase1" cx = "12" cy = "45" r = "5"></circle>
               <path id = "full_phase2" transform = "" d = "M 12,50 A 5,5 0 1,0 12,50 Z"></path>

               <circle class = "svg_legend" id = "q2_phase1" cx = "12" cy = "60" r = "5"></circle>
               <path class = "svg_legend" id = "q2_phase2"   transform = "" d = "M 12,65 A 5,5 0 1,0 12,55 Z"></path>

          
               <text class = "legend_text" id = "calendar_type" x = "690" y = "19">Julian Calendar</text>
               <text class = "legend_text" id = "new_text"  x = "22" y = "19">New Moon</text>
               <text class = "legend_text" id = "q1_text"   x = "22" y = "34">First Quarter</text>
               <text class = "legend_text" id = "full_text" x = "22" y = "49">Full Moon</text>
               <text class = "legend_text" id = "q2_text"   x = "22" y = "64">Last Quarter</text>
            </svg>
         </svg>
      </div> 

   </div> <!-- End outline div
   
   
   </td>
   <td id="buttonPanel" class="hideable">
      <div id="panelStrip" class="hideable centered">
         <button id="resetButton" >...</button>
         <button id="settingsButton">...</button>
      </div>
   </td> 
   </tr>
   </table>
   
   <div id = "preferences" class = "hideable">
   
   <form class = "hideable">
   
      <div class="prefs_buttons">
         <input type="checkbox" id="prefs_tooltips" /><label for="prefs_tooltips">Tooltips</label>
         <input type="checkbox" id="prefs_legend" /><label for="prefs_legend">Legend</label>
         <input type="checkbox" id="prefs_positionAngle" /><label for="prefs_positionAngle">Position Angle</label>
      </div>   
      
      <div class="prefs_buttons">

         <button id="prefs_northUp">North Up</button>
         <button id="prefs_timeFormat">6 Hour Format</button>
      </div>
      
      <div class = "wrapper">
      <label class = "prefs_firstDayOfWeek" for="prefs_firstDayOfWeek">First Day of Week</label>
      <select name = "prefs_firstDayOfWeek" id="prefs_firstDayOfWeek">
         <option value="0">Sunday</option>
         <option value="1">Monday</option>
         <option value="2">Tuesday</option>
         <option value="3">Wednesday</option>
         <option value="4">Thursday</option>
         <option value="5">Friday</option>
         <option value="6">Saturday</option>
      </select>
      </div>
      
      <div class = "wrapper">
      <label class = "prefs_scaling" for="prefs_scaling">Scaling</label>
      <select name = "prefs_scaling" id="prefs_scaling">
         <option value="normal">Normal</option>
         <option value="none">None</option>
         <option value="exaggerated">Exaggerated</option>
      </select>
      </div>
      
      <label class = "prefs_phaseTime" for="prefs_phaseTime">Phase Times</label>
      <select name = "prefs_phaseTime" id="prefs_phaseTime">
         <option value="localTime">Local Time</option>
         <option value="localMidnight">Local Midnight</option>
         <option value="utcMidnight">UTC Midnight</option>
      </select>
      
      <div class="ui-widget">
         <label class = "prefs_gregorianJD1" for="prefs_gregorianJD1">First Date in Gregorian Calendar</label>
         <input id="prefs_gregorianJD1">
      </div>
      
   </form>
   
   </div>
   
   
   <br /> <br />
   

   <br style="clear:both"> -->
   <html>
    <head>
        <title>MoonCalendar</title>
        <!-- <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
        <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->
        <link rel="stylesheet" type="text/css" href="calendarr.css">
        <link href="http://fonts.googleapis.com/css?family=Chewy:regular" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link type="text/css" rel="stylesheet" href="styles/pc.css"/>

    </head>
    <link href="css/themes/jquery-ui.min.css" rel="stylesheet" />
   <link href="css/mooncalendar_styles.css" rel="stylesheet" />
   <script src="scripts/jquery/jquery-2.1.1.min.js"></script>
   <script src="jquery-ui.min.js"></script>
   <script src="scripts/jquery/jquery.cookie.js" type="text/javascript"></script>
   <script src="scripts/jquery/jquery-calendars/jquery.calendars.js" type="text/javascript"></script>
   <script src="scripts/jquery/jquery-calendars/jquery.calendars.julian.min.js" type="text/javascript"></script>
   <script src="scripts/jquery/jquery-calendars/jquery.calendars.lang.min.js" type="text/javascript"></script>
   <script src="scripts/jquery/jquery-calendars/jquery.calendars.plus.min.js" type="text/javascript"></script>
   <script src="scripts/DateSelector.js" type="text/javascript"></script>
   <script src="astro/LunarPosition.js" type="text/javascript"></script>
   <script src="astro/SolarPosition.js" type="text/javascript"></script>
   <script src="astro/astro_utils.js" type="text/javascript"></script>
   <script src="scripts/calendar_preferences.js" type="text/javascript"></script>
   <script src="scripts/pmc_utils.js" type="text/javascript"></script>
    <script>
      function addLoadEvent(func)
      {
         var oldonload = window.onload;
         if (typeof window.onload != 'function')
         {
           window.onload = func;
         }
         else
         {
           window.onload = function()
           {
             if (oldonload)
             {
               oldonload();
             }
             func();
           }
         }
      }

      addLoadEvent(function()
      {
         var hasSVG = !!(document.createElementNS &&
                         document.createElementNS('http://www.w3.org/2000/svg', 'svg').createSVGRect);

         var svgWarning = document.getElementById("svgWarning");
         var mooncalendar = document.getElementById("mooncalendar");

         if (hasSVG === false)
         {
           // svgWarning.setAttribute("style", "display:block;");
            mooncalendar.setAttribute("style", "display:none;");
         }
         else
         {
           // svgWarning.setAttribute("style", "display:none;");
            mooncalendar.setAttribute("style", "display:table;");
         }
      });
   </script>

   <script>
      $(document).ready(function()
      {
      
                      
         var mooncalendar = document.getElementById("mooncalendar");
         var svgWarning = document.getElementById("svgWarning");

         
         var hasSVG = !!(document.createElementNS &&
                         document.createElementNS('http://www.w3.org/2000/svg', 'svg').createSVGRect);
         
         if (hasSVG === false)
         {

            mooncalendar.setAttribute("style", "display:none;");
         }

         {
  
            window.preferences.loadPreferences();
            window.preferences.savePreferences();
            
            mooncalendar.setAttribute("style", "display:table;");
                        
            var basewidth = pmc_utils.getBaseWidth(); 
            
            if (basewidth === 6.0)
            {
               $("#DateDisplay").css("font-size", "22.5pt");
               $(".mcds li").css("font-size", "18pt");
            }
            else
            {
               $("#DateDisplay").css("font-size", "30pt");
               $(".mcds li").css("font-size", "24pt");
            }
    
            console.log("Preferences loaded.");
            
            for (key in window.preferences.values)
               console.log("key: " + key + " val: " + window.preferences.values[key]);
            
            
            console.log("Version.revision: " + window.preferences.values["version"] + "." + window.preferences.values["revision"]);
            
            pmc_utils.initWeekdayLabels();
            pmc_utils.initGrid();

            jQuery(document).bind('month_changed_event', pmc_utils.handleMonthChange);

            pmc_utils.setToCurrentDate();
            
            var preferencesDialog = pmc_utils.getPreferencesDialog();
            
            $(function()
            {
               var resetButton = $("#resetButton").text("").append("<img src=images/reset.png />").button();
               resetButton.click(function() {pmc_utils.setToCurrentDate();});


               var settingsButton = $("#settingsButton").text("").append("<img src=images/gear.png />").button();
               settingsButton.click(function() {preferencesDialog.dialog("open"); });

               $("#prefs_tooltips").button().click(pmc_utils.getCheckboxHandler($("#prefs_tooltips"), "tooltips"));
               $("#prefs_northUp").button().click(pmc_utils.getToggleButtonHandler2($("#prefs_northUp"), "northUp"));
               $("#prefs_positionAngle").button().click(pmc_utils.getCheckboxHandler($("#prefs_positionAngle"), "positionAngle"));
               
               $("#prefs_legend").button().click(pmc_utils.getCheckboxHandler($("#prefs_legend"), "legend"));
               $("#prefs_timeFormat").button().click(pmc_utils.getToggleButtonHandler($("#prefs_timeFormat"), "timeFormat"));
               
               $("#prefs_firstDayOfWeek").selectmenu({
                                                        change: function(event, data)
                                                                {
                                                                   window.preferences.values["firstDayOfWeek"] = data.item.value;
                                                                   pmc_utils.triggerRedraw();
                                                                }
                                                     });
               $("#prefs_firstDayOfWeek").selectmenu({width: "auto"});
               $("#prefs_firstDayOfWeek").selectmenu("refresh");
                                                     
               $("#prefs_language").selectmenu({
                                                  change: function(event, data)
                                                          {
                                                             window.preferences.values["language"] = data.item.value;
                                                             pmc_utils.triggerRedraw();
                                                          }
                                                     });
               $("#prefs_language").selectmenu({width: "auto"});
               $("#prefs_language").selectmenu("refresh");
               
               $("#prefs_scaling").selectmenu({
                                                  change: function(event, data)
                                                          {
                                                             window.preferences.values["scaling"] = data.item.value;
                                                             pmc_utils.triggerRedraw();
                                                          }
                                                     });
               $("#prefs_scaling").selectmenu({width: "auto"});
               $("#prefs_scaling").selectmenu("refresh");
               
               $("#prefs_phaseTime").selectmenu({
                                                  change: function(event, data)
                                                          {
                                                             window.preferences.values["phaseTime"] = data.item.value;
                                                             pmc_utils.triggerRedraw();
                                                          }
                                                     });
               $("#prefs_phaseTime").selectmenu({width: "auto"});
               $("#prefs_phaseTime").selectmenu("refresh");
               
               var availableTags = [];
               $("#prefs_gregorianJD1").autocomplete({
                                                        source: availableTags,
                                                        change: pmc_utils.parseDate
                                                     });
            });
         }
      });
   </script>
    <body>
        <main>	
            <button id ="theme_btn"> Theme</button> </main>
            <script type="text/javascript" src="calendarr.js"></script>
            <div class="navbar">
<a href="http://localhost/google/testpage.php"><img src = 'images/logo1.png'></a></a>
  <a href="testpage.php">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Calendar 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="calendarr.php" class="active">Gregorian</a>
      <a href="mooncalendar.php">Lunar</a>

    </div>
  </div> 
    <a href="notekeeping.php">Notes</a>
    <a href="about.php">About</a>
    <div class="dropdown">
                    <!-- <a href="#" class="dropdown-toggle profile-image" data-toggle="dropdown"> -->
                    <?php include_once 'google.php';
                    echo $profile;
                    echo $name; ?> 
                   <i class="fa fa-caret-down"></i>
                    <div class="dropdown-content">
                        <a href="#">Account</a>
                        <a href="logout.php">Sign-out</a>
                	</div>
 
</div>
</div>
        <table id="mooncalendar" class="centered">
   <tr>
   <td class="centered">

   <div id="Outline">
   
      <div id="DateDisplay">
         January 2014 AD
      </div>
      
      <div id="DateSelector">
         <ul class="mcds">
            <li><div id="month">Loading...</div><span id="monthVal">0</span>
               <ul>
                  <li><div id="month0">January</div>  <span class="val">0</span></li>
                  <li><div id="month1">February</div> <span class="val">1</span></li>
                  <li><div id="month2">March</div>    <span class="val">2</span></li>
                  <li><div id="month3">April</div>    <span class="val">3</span></li>
                  <li><div id="month4">May</div>      <span class="val">4</span></li>
                  <li><div id="month5">June</div>     <span class="val">5</span></li>
                  <li><div id="month6">July</div>     <span class="val">6</span></li>
                  <li><div id="month7">August</div>   <span class="val">7</span></li>
                  <li><div id="month8">September</div><span class="val">8</span></li>
                  <li><div id="month9">October</div>  <span class="val">9</span></li>
                  <li><div id="month10">November</div><span class="val">10</span></li>
                  <li><div id="month11">December</div><span class="val">11</span></li>
               </ul>
            </li>

            <li><div id="millenium"></div><span id="milleniumVal">0</span>
               <ul>
                  <li><div id="millenium0">0</div><span class="val">0</span></li>
                  <li><div id="millenium1">1</div><span class="val">1</span></li>
                  <li><div id="millenium2">2</div><span class="val">2</span></li>
                  <li><div id="millenium3">3</div><span class="val">3</span></li>
               </ul>
            </li>
            <li><div id="century"></div><span id="centuryVal">0</span>
               <ul>
                  <li><div id="century0">0</div><span class="val">0</span></li>
                  <li><div id="century1">1</div><span class="val">1</span></li>
                  <li><div id="century2">2</div><span class="val">2</span></li>
                  <li><div id="century3">3</div><span class="val">3</span></li>
                  <li><div id="century4">4</div><span class="val">4</span></li>
                  <li><div id="century5">5</div><span class="val">5</span></li>
                  <li><div id="century6">6</div><span class="val">6</span></li>
                  <li><div id="century7">7</div><span class="val">7</span></li>
                  <li><div id="century8">8</div><span class="val">8</span></li>
                  <li><div id="century9">9</div><span class="val">9</span></li>
               </ul>
            </li>
            <li><div id="decade"></div><span id="decadeVal">0</span>
               <ul>
                  <li><div id="decade0">0</div><span class="val">0</span></li>
                  <li><div id="decade1">1</div><span class="val">1</span></li>
                  <li><div id="decade2">2</div><span class="val">2</span></li>
                  <li><div id="decade3">3</div><span class="val">3</span></li>
                  <li><div id="decade4">4</div><span class="val">4</span></li>
                  <li><div id="decade5">5</div><span class="val">5</span></li>
                  <li><div id="decade6">6</div><span class="val">6</span></li>
                  <li><div id="decade7">7</div><span class="val">7</span></li>
                  <li><div id="decade8">8</div><span class="val">8</span></li>
                  <li><div id="decade9">9</div><span class="val">9</span></li>
               </ul>
            </li>
            <li><div id="year"></div><span id="yearVal">0</span>
               <ul>
                  <li><div id="year0">0</div><span class="val">0</span></li>
                  <li><div id="year1">1</div><span class="val">1</span></li>
                  <li><div id="year2">2</div><span class="val">2</span></li>
                  <li><div id="year3">3</div><span class="val">3</span></li>
                  <li><div id="year4">4</div><span class="val">4</span></li>
                  <li><div id="year5">5</div><span class="val">5</span></li>
                  <li><div id="year6">6</div><span class="val">6</span></li>
                  <li><div id="year7">7</div><span class="val">7</span></li>
                  <li><div id="year8">8</div><span class="val">8</span></li>
                  <li><div id="year9">9</div><span class="val">9</span></li>
               </ul>
            </li>

            <li><div id="epoch"></div><span id="epochVal">0</span>
               <ul>
                  <li><div id="epochAD">AD</div><span class="val">AD</span></li>
                  <li><div id="epochBC">BC</div><span class="val">BC</span></li>
               </ul>
            </li>
         </ul>
      </div>

      <div id="Calendar">
         <svg id="svg_calendar" width="8.0in" height="7.2in" viewBox="0 0 700 730" shape-rendering="geometricPrecision">
            <svg id="weekday_bar" width="700" height="30" ></svg>
            <svg id="calendar_grid" width="700" height="600" y="30" viewBox="0 0 700 600" ></svg>
   
            <svg class="svg_legend" id = "svg_calendar_legend" width = "700" height = "100" y = "330" viewBox="0 0 700 100">
               <circle class = "svg_legend" id = "new_phase1" cx = "12" cy = "15" r = "5"></circle>
               <path class = "svg_legend" id = "new_phase2"  transform = "" d = "M 12,20 A 5,5 0 1,0 12,10 Z"></path>

               <circle class = "svg_legend" id = "q1_phase1" cx = "12" cy = "30" r = "5"></circle>
               <path class = "svg_legend" id = "q1_phase2"   transform = "" d = "M 12,35 A 5,5 0 1,0 12,25 Z"></path>

               <circle class = "svg_legend" id = "full_phase1" cx = "12" cy = "45" r = "5"></circle>
               <path id = "full_phase2" transform = "" d = "M 12,50 A 5,5 0 1,0 12,50 Z"></path>

               <circle class = "svg_legend" id = "q2_phase1" cx = "12" cy = "60" r = "5"></circle>
               <path class = "svg_legend" id = "q2_phase2"   transform = "" d = "M 12,65 A 5,5 0 1,0 12,55 Z"></path>

          
               <text class = "legend_text" id = "calendar_type" x = "690" y = "19">Julian Calendar</text>
               <text class = "legend_text" id = "new_text"  x = "22" y = "19">New Moon</text>
               <text class = "legend_text" id = "q1_text"   x = "22" y = "34">First Quarter</text>
               <text class = "legend_text" id = "full_text" x = "22" y = "49">Full Moon</text>
               <text class = "legend_text" id = "q2_text"   x = "22" y = "64">Last Quarter</text>
            </svg>
         </svg>
      </div> 

   </div> 
   <!-- End outline div-->
   
   
   </td>
   <td id="buttonPanel" class="hideable">
      <div id="panelStrip" class="hideable centered">
         <button id="resetButton" >...</button>
         <button id="settingsButton">...</button>
      </div>
   </td> 
   </tr>
   </table>
   
   <div id = "preferences" class = "hideable">
   
   <form class = "hideable">
   
      <div class="prefs_buttons">
         <input type="checkbox" id="prefs_tooltips" /><label for="prefs_tooltips">Tooltips</label>
         <input type="checkbox" id="prefs_legend" /><label for="prefs_legend">Legend</label>
         <input type="checkbox" id="prefs_positionAngle" /><label for="prefs_positionAngle">Position Angle</label>
      </div>   
      
      <div class="prefs_buttons">

         <button id="prefs_northUp">North Up</button>
         <button id="prefs_timeFormat">6 Hour Format</button>
      </div>
      
      <div class = "wrapper">
      <label class = "prefs_firstDayOfWeek" for="prefs_firstDayOfWeek">First Day of Week</label>
      <select name = "prefs_firstDayOfWeek" id="prefs_firstDayOfWeek">
         <option value="0">Sunday</option>
         <option value="1">Monday</option>
         <option value="2">Tuesday</option>
         <option value="3">Wednesday</option>
         <option value="4">Thursday</option>
         <option value="5">Friday</option>
         <option value="6">Saturday</option>
      </select>
      </div>
      
      <div class = "wrapper">
      <label class = "prefs_scaling" for="prefs_scaling">Scaling</label>
      <select name = "prefs_scaling" id="prefs_scaling">
         <option value="normal">Normal</option>
         <option value="none">None</option>
         <option value="exaggerated">Exaggerated</option>
      </select>
      </div>
      
      <label class = "prefs_phaseTime" for="prefs_phaseTime">Phase Times</label>
      <select name = "prefs_phaseTime" id="prefs_phaseTime">
         <option value="localTime">Local Time</option>
         <option value="localMidnight">Local Midnight</option>
         <option value="utcMidnight">UTC Midnight</option>
      </select>
      
      <div class="ui-widget">
         <label class = "prefs_gregorianJD1" for="prefs_gregorianJD1">First Date in Gregorian Calendar</label>
         <input id="prefs_gregorianJD1">
      </div>
      
   </form>
   
   </div>
   
   
   <br /> <br />
   

   <br style="clear:both">
   </body>
</html>
