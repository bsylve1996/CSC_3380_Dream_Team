<!DOCTYPE html>
<html>
    <head>
        <title>About</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="calendarr.css">
<style>
 body{
   background:#230741;
 }
  </style>

</head>
<body>
<div class="navbar">
<a href="http://localhost/google/testpage.php"><img src = 'images/logo1.png'></a></a>
  <a href="testpage.php">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Calendar 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="calendarr.php" class="active">Gregorian</a>
      <a href="mooncalendar.php">Lunar</a>

    </div>
  </div> 
    <a href="notekeeping.php">Notes</a>
    <a href="about.php">About</a>
    <div class="dropdown">
                    <!-- <a href="#" class="dropdown-toggle profile-image" data-toggle="dropdown"> -->
                    <?php include_once 'google.php';
                    echo $profile;
                    echo $name; ?> 
                    <i class="fa fa-caret-down"></i>
                    <div class="dropdown-content">
                        <a href="#">Account</a>
                        <a href="logout.php">Sign-out</a>
                	</div>
 
</div>
</div>
<div style = "background: #a068b1;">
<h2>About Us</h2>
<div >
  <p>
  <div style= "padding-left:20px;">
    <img src="images/imaan_tomato.png" alt="tomatoHijab" width="100" height="100" border ="3" align="left">
</div>
  <div style= "background:#e6bff2;  margin-left:150px; margin-right:50px; ">
    <div class = "name"> <p style="text-indent: 20px"> Imaan Wada</p></div>  
  <p style ="text-indent: 10px"> "You're rude.  Stop being rude." </p> 
  <p style="text-align:left; padding-left:20px;"> Sassy yet extremely fashionable hibaji woman who created the gregorian calendar on our Schedulr application. 
  Imaan also implemented the dawn and dusk themes for the calendar page as of right now. She just wants to go back home to Britain.</p>
</div>
</div>
<br>
<br>
<br>
<br>
<div >
  <p>
  <div style= "padding-left:20px;">
    <img src="images/potato.jpg" alt="Potato" width="100" height="100" border ="3" align="left">
</div>
    <div style= "background:#e6bff2;  margin-left:150px; margin-right:50px; ">
  <div class = "name"> <p style ="text-indent: 10px"> Vanessa Hoffmann </p></div>
  <p style ="text-indent: 10px"> "I told you; you didn't listen." </p> 
      <p style="text-align:left;padding-left:20px;"> Probably the tallest on our team; Vanessa's pretty chill and mellow but also really funny with an underlayer of sass.
        She created the about page for calendar and has adjusted the layouts on some of the other pages for Calendar. Works on this project at totally reasonable times.</p>
</div> 
</div>
<p>
  <br>
<br>
<br>
<br>
<div >
  <p>
  <div style= "padding-left:20px;">
    <img src="images/icon.png" alt="jadey_boi" width="100" height="100" border ="3" align="left">
</div>
    <div style= "background:#e6bff2;  margin-left:150px; margin-right:50px; ">
      <div class = "name"> <p style="text-indent: 20px"> Elizabeth Alvarado </p> </div> 
      <p style ="text-indent: 10px"> Disaster Lesbian </p> 
      <p style="text-align:left;padding-left:20px;"> Elizabeth, as one of the more graphics oriented people on the team, designed the graphical layout for most of the pages in Calendar, 
        and she also created the palettes to be used for the dawn and dusk themes for the application. She also created the Monday-starting calendar for Calendar.</p>
</div> 
</div>
<br>
<br>
<br>
<br>
<br>
<div >
  <p>
  <div style= "padding-left:20px;">
    <img src="images/tangerine.png" alt="Tangerine" width="100" height="100" border ="3" align="left">
</div>
    <div style= "background:#e6bff2;  margin-left:150px; margin-right:50px; ">
      <div class = "name"> <p style ="text-indent: 10px"> Myla Moore </p></div>
  <p style ="text-indent: 10px"> "Okay. I'm done; goodbye." </p> 
      <p style="text-align:left;padding-left:20px;"> Myla created our lunar calendar! And finally got it working! 
  She has been working hard on it and finally got it to work. We are all happy for her. She's a tired college student and RA.</p>
</div>
</div>
<br>
<br>
<br>
<br>
<br>
<div>
  <p>
  <div style= "padding-left:20px;">
    <img src="images/apple.png" alt="apple" width="100" height="100" border ="3" align="left">
</div>
    <div style= "background:#e6bff2;  margin-left:150px; margin-right:50px; ">
      <div class = "name"> <p style ="text-indent: 10px"> Aliza Bista </p></div>
  <p style ="text-indent: 10px"> The Saviour of the Login System </p> 
      <p style="text-align:left;padding-left:20px;"> Aliza is very sweet and works hard to get things done. She got our login system working so that you can access the application,
  and she lets the team know of any problems that occur while testing it out on FireBase.</p>
</div>
</div>
<br>
<br>
<br>
<br>
<br>
<div >
  <p>
    <div style= "padding-left:20px;">
    <img src="images/grape_bra.png" alt="grape" width="100" height="100" border ="3" align="left" >
    </div>
    <div style= "background:#e6bff2;  margin-left:150px; margin-right:50px; ">
      <div class = "name"> <p style ="text-indent: 10px"> Brandon Sylve </p></div>
  <p style ="text-indent: 10px"> "Literally." </p> 
      <p style="text-align:left;padding-left:20px;"> What doesn't Brandon do? Literally, he's probably in everything. Just to list off a few things,
  he does RA, army, ACM, and DM; guy's busy but gets stuff done and has it working. 
        Brandon created our clock on the application and also implemented the timezones in it.</p>
</div>

</div>
</div> 
 </body>
</html>