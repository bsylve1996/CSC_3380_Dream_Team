<?php

//id int, Tiltle varchar, Message text, time timestamp]
 $dbHost     = "localhost";
 $dbUsername = 'root';
    // Password of database 12345
 $dbPassword = '';
    //name of the database
  $dbName     = "notekeeping";
    //name if the database table
   $userTbl    = 'notekeeping';
   $conn = mysql_connect($dbHost, $dbUsername, $dbPassword);

$sql = 'SELECT Title, Message From notekeeping';
mysql_select_db('notekeeping');
$retval = mysql_query($sql, $conn);
if(!$retval){
	die('Could not get data: ' .mysql_error());
}
while($row = mysql_fetch_assoc($retval)){
	echo "{$row['Title']} ".
    	 "{$row['Message']} <br>";
 }

mysql_close($conn);
?>