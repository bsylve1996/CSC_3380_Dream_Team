# CSC_3380_Dream_Team


This is a calendar that allows one to view the lunar calendar for any given month. It displays what the moon phase will be for each given day of a month.

The program also allows for various preferences such as:
Changing the first day of the week
Moon angles
Changing the time to 24 hour format 
Changing time zones 
and more...

This lunar calendar implements the jquery calendar library as well as uses behaviors from Paul Carlisle's Complete Calendar Library. 