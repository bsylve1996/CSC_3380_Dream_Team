<html>
<head>
<!-- <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="calendarr.css">
<link rel="stylesheet" type="text/css" href="clock.css">

</head>
<body>
<div class="navbar">
<a href="http://localhost/google/testpage.php"><img src = 'images/logo1.png'></a></a>
  <a href="testpage.php" class="active">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Calendar 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="calendarr.php">Gregorian</a>
	  <a href="mooncalendar.php">Lunar</a>
	  <a href="mon_startcalendarr.php">Latin</a>

    </div>
  </div> 
    <a href="notekeeping.php">Notes</a>
    <a href="about.php">About</a>
    <div class="dropdown">
                    <!-- <a href="#" class="dropdown-toggle profile-image" data-toggle="dropdown"> -->
                    <?php include_once 'google.php';
                    echo $profile;
                    echo $name; ?> 
                   <i class="fa fa-caret-down"></i>
                    <div class="dropdown-content">
                        <a href="#">Account</a>
                        <a href="logout.php">Sign-out</a>
                	</div>
 
</div>
</div>
<div class ="catman">
    <div class = "urmom">
         <form name="TimeZone">
		    	<p>Want to change your time zone?
			    <select id="optionList" onchange="changeTimeZone(this.form)">
				    <option value=0>Time Zones</option>
				    <option value=1 name="Hawaian">Hawaian</option>
				    <option value=2 nane="Alaska">Alaska</option>
				    <option value=3 name="Pacific">Pacific</option>
				    <option value=4 name="Mountain">Mountain</option>
				    <option value=5 name="Central">Central</option>
				    <option value=6 name="Eastern">Eastern</option>
			    </select>
		</form>
		<script type="text/javascript">
			function changeTimeZone(myForm){
				var selindex = myForm.optionList.selectedIndex;
				var d = changeTheTime(selindex);
			}
		</script>
		<script type="text/javascript" src="currentTimeObject.js"></script>
		 <p id="timeNow">
		<script type="text/javascript">
			function updateTimeHTML() {
				var time = getTime();
				document.getElementById("timeNow").innerHTML = time;
				localStorage.setItem('time', time);
			}
			setInterval(updateTimeHTML, 1*1*1000 );//minutes*seconds*millisecond
		</script>
		<link type="text/css" rel="stylesheet" href="clock.css"/>
		<div id="time"></div><br>
		<div id="clock">
		  <div class="num num1"><div>1</div></div>
		  <div class="num num2"><div>2</div></div>
		  <div class="num num3"><div>3</div></div>
		  <div class="num num4"><div>4</div></div>
		  <div class="num num5"><div>5</div></div>
		  <div class="num num6"><div>6</div></div>
		  <div class="num num7"><div>7</div></div>
		  <div class="num num8"><div>8</div></div>
		  <div class="num num9"><div>9</div></div>
		  <div class="num num10"><div>10</div></div>
		  <div class="num num11"><div>11</div></div>
		  <div class="num num12"><div>12</div></div>
		  <div id="hr-hand"></div>
		  <div id="min-hand"></div>
		  <div id="sec-hand"></div>
        </div>
        <div class ="buttons"><a href="#" class="previous round">&#8249;</a>
        <a href="calendarr.php" class="next round">&#8250;</a></div>
    </div>
</div>
</body>
</html>