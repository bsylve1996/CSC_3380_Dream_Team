<html>
<head>
     <title>Calendar</title>
     <link rel="stylesheet" type="text/css" href="calendarr.css">
        <link href="http://fonts.googleapis.com/css?family=Chewy:regular" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" type="text/css" href="mon_startcalendarr.css"> -->
  <script type="text/javascript" src="mon_startcalendarr.js"></script>
</head>
    <body>

<main>	<button id ="theme_btn"> Theme</button> </main>
    <script type="text/javascript" src="mon_startcalendarr.js"></script>
    <div class="navbar">
<a href="http://localhost/google/testpage.php"><img src = 'images/logo1.png'></a></a>
  <a href="testpage.php">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Calendar 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="calendarr.php" >Gregorian</a>
      <a href="mooncalendar.php" class="active">Lunar</a>
      <a href="mon_startcalendarr.php">Latin</a>

    </div>
  </div> 
    <a href="notekeeping.php">Notes</a>
    <a href="about.php">About</a>
    <div class="dropdown">
                    <!-- <a href="#" class="dropdown-toggle profile-image" data-toggle="dropdown"> -->
                    <?php include_once 'google.php';
                    echo $profile;
                    echo $name; ?> 
                   <i class="fa fa-caret-down"></i>
                    <div class="dropdown-content">
                        <a href="#">Account</a>
                        <a href="logout.php">Sign-out</a>
                	</div>
 
</div>
</div>
 
<div style="padding-left:16px">
 <div class="bodycontainer">
	<div id ="sidepane">
	 <h1>Time</h1>
        <p id ="time"></p>
        <script> 
            document.getElementById('time').innerHTML = localStorage.getItem('time');
        </script>
     	</div>
        <div id="calendar-container">
            <div id="calendar-header">
                <span id="calendar-month-year"></span>
            </div>
            <div id="calendar-dates">
            </div>
        </div>
		<div id = "event-container">
        </div>
</div>
    
    </body>
</html>