<?php
class connect {
	private $dbHost     = "localhost";
    private $dbUsername = 'root';
    // Password of database 12345
    private $dbPassword = '';
    //name of the database
    private $dbName     = "notekeeping";
    //name if the database table
    private $userTbl    = 'notekeeping';
	function __construct(){
        if(!isset($this->db)){
            // Connect to the database
            $conn = new mysqli($this->dbHost, $this->dbUsername,$this->dbPassword,$this->dbName);
            if($conn->connect_error){
                die("Failed to connect with MySQL: " . $conn->connect_error);
            }else{
                $this->db = $conn;
            }
        }
    }
	
	function checkNote($userData = array()){
                $prevQuery = "SELECT 'Message' FROM ".$this->userTbl." ";
            $prevResult = $this->db->query($prevQuery);


                //Insert user data
                $query = "INSERT INTO ".$this->userTbl." SET Title = '".$userData['Title']."', Message = '".$userData['Message']."',  time = '".date("Y-m-d H:i:s")."'";
                $insert = $this->db->query($query);
         //Get user data from the database
            $result = $this->db->query($prevQuery);
            $userDatas = array();
            while( $userData = $result->fetch_assoc()){
                $userDatas[] = array('userData' => $userData['Message']);

            };
        //Return user data
        return $userDatas;
    }
}
?>