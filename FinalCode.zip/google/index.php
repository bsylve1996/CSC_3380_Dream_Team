
<html>
<head>
<title>Welcome</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rl="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src ="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
  <style>
  body {
   margin: 0;
  }

  /* Style the header */
  .header {
      background-color: #071A44;
      padding: 0px;
      text-align: center;
}

/* Style the Top Row */
  .topRow {
      padding: 5px;
      text-align: center;
      width:500;
      margin:0 auto;
    }
    

.topnav {
  overflow: hidden;
  background-color: #a068b1;
  text-align:center;
  max-width: 500px;
  margin:0 auto;
  padding:1px;
}


.topnav a {
  color: #230741;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
  display:inline-block;

}
.topnav li{
	display:inline;

}

.topnav a:hover {
  background-color: #d6af38;
  color: white;
}

.topnav a.active {
  background-color: #a068b1;
  color:white;
}
.body-text{
background-color:#a068b1;
width:800px;

height:1000px;
margin:0 auto;
margin-bottom: 20px;


}
p{
	color:white;
	text-align: left;
	padding-left:100px;
	padding-right:100px;
}
body{
	background-color: #071A44;

}
.subtitle{
	color:white;
	font-size:25px;
	text-align: center;
	padding:25px;
	padding-bottom: 10px;
}

</style>
</head>
<body>

<div class="header">
  <h1 style="color: #63B0e6">Welcome to Calendar!</h1>
</div>

<div class = "body-text">
<div class="topRow">
<img src = 'images/logo1.png'>
</div>
	<h2 class = "subtitle">What We Offer:</h2>
<p> 
	We here at Calendar offer you access to different types of calendars and time keeping options. We felt that
	people don't think about time enough because its always ticking and we want to help you tack it so when you feel like you've run out of time at least it wasnt wasted cause you planned it to a t with the use of our calendars which are super cool and awesome and make you go wow im glad this exists in the world cause I need this.

<br>
<br>
<br>
<br>
<br>
<div style = "margin-left:260px;">
    <div class="col-xs-12 col-md-8">
            <?php
            include_once 'google.php';
            ?>
             <?php echo $logo; ?></div> 

    <div class="col-xs-12 col-md-8">
        <?php
        include_once 'facebook.php';
        ?>
         <?php echo $output; ?></div> 
         </div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<h2 style= "color:white">What People Say About Us</h2>
<br>
<br>
<br>
<div >
<div style= "padding-left:20px;">
    <img src="images/imaan_tomato.png" alt="tomatoHijab" width="100" height="100" border ="3" align="left">
</div>
  <div style= "background:#e6bff2;  margin-left:150px; margin-right:50px; ">
    
  <p style ="text-align:center; padding-top:25;padding-bottom: 25px;"> This is pretty great! </p> 
  <p style="text-align:right; padding-bottom:25px;">-Adam </p>
</div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>

	</div>
</body>
</html>